function features=MI_order(data,k)

[n,p]=size(data);

classMI=[];
for i = 1 : p-1
classMI(i) = mi(data(:,i),data(:,p));
end

[a,b]=sort(classMI,'descend');

features=b(1:k);

