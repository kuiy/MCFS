function [score] = mi_c(firstVector,secondVector)


C=cov([firstVector,secondVector]);
size_C=size(C,2);
X1=1;
Y1=2;
S1=[3:size_C];


r = partial_corr_coef(C, X1, Y1, S1);
score=1/2*log2(1-r*r);
