
function [mb,ntest,time]=hiton_mb_g2(Data,target, alpha)

start=tic;

maxK=3;
[~,p]=size(Data);

%ns stores the number of discrete values of each variable in Data
ns=max(Data);

ntest=0;


sp=[];%spouses of the input target
mb=[];%MB of the input target

% Finding pc (parents and children ) of the target vaiable
[pc,ntest1,sepset]=HITONPC_G2(Data,target,alpha, ns, p, maxK);

 ntest=ntest+ntest1;
 mb=[mb pc];

 
for i=1:length(pc)

    [pc_tmp,ntest2]=HITONPC_G2(Data,pc(i),alpha, ns, p, maxK);
     ntest=ntest+ntest2;
     for j=1:length(pc_tmp)
         
         if isempty(find(pc==pc_tmp(j), 1))&& pc_tmp(j)~=target && isempty(find(sepset{pc_tmp(j)}==pc(i), 1))
             
             [pval]=my_g2test(pc_tmp(j),target,[sepset{pc_tmp(j)},pc(i)],Data,ns);
             
             if isnan(pval)
                 CI=0;
             else
                 if pval<=alpha
                     CI=0;
                 else
                     CI=1;
                 end
             end
             
             ntest=ntest+1;
             if CI==0
                 sp=myunion(sp,pc_tmp(j));
             end
         end
     end
end

mb=myunion(mb,sp);
time=toc(start);