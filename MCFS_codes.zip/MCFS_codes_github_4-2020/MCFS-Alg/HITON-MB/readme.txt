
Input parameter: 

1. Data: input data set:

2. target: The index of the target variable in Data

3. alpha: Significance level for the G^2  test (always set 0.01 or 0.05)

Output:

mb: the learnt mb of the input target variable

ntest: the number of conditional independence tests

time: running time in seconds

sepset: a conditional set that makes a variable and the input target variable conditionally independent



hiton-mb-g2: for discrete data using the G^2  test.

Note: the discrete data values of each variable in Data need to be from 1.
From example, varible X has three discrete values that is, [1 2 3], while not [ 0 1 2].


hiton-mb-z: for continuous data using the Fisher Z  test.