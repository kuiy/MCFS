function [mb,ntest,time,sepset]=hiton_mb_z(Data,target, alpha)


start=tic;

maxK=3;
[m,p]=size(Data);

ntest=0;

sp=[];%spouses of the input target
mb=[];%MB of the input target

% Finding pc (parents and children ) of the target vaiable
[pc,ntest1,sepset]=HITONPC_Z(Data,target,alpha, m,p, maxK);

ntest=ntest+ntest1;
mb=[mb pc];

for i=1:length(pc)
    
    [pc_tmp,ntest2]=HITONPC_Z(Data,pc(i),alpha, m,p, maxK);
    
    ntest=ntest+ntest2;
    for j=1:length(pc_tmp)
        
        if isempty(find(pc==pc_tmp(j), 1))&& pc_tmp(j)~=target && isempty(find(sepset{pc_tmp(j)}==pc(i), 1))
            
            ntest=ntest+1;
            [CI]=my_fisherz_test(Data,pc_tmp(j),target,[sepset{pc_tmp(j)},pc(i)],m,alpha);
            
            if CI==0
                sp=myunion(sp,pc_tmp(j));
            end
        end
    end
end

mb=myunion(mb,sp);
time=toc(start);

