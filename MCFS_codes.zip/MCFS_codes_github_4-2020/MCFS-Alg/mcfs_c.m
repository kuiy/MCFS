function [selFea,time] =mcfs_c(data,target,alpha)

%for continuous data,class label is discreet


% Input :
%       data is the data matrix, NbVar columns * N rows
%       target is the index of target variable
%       alpha is the significance level
%
%output:
%       SelFea: the selected feature sets 
%       time is the runtime of the algorithm



start1=tic;
selFea=[];
time=0;

M=length(data);
ave_score=0;

mb1=cell(1,M);
mb=[];

for i=1:M
 [mb1{i}]=Causal_Explorer('HITON_MB', data{i},target, [], 'z', alpha, 3);
 % [mb1{i}]=hiton_mb_z(data{i},target, alpha);
  [a11,b11]=size(mb1{i});
  if a11>1
      mb1{i}=mb1{i}';
  end
  mb=[mb mb1{i}];
end

mb=unique(mb);

nn=1;
selFea{nn}=[];
ss=subsetsFixedSize(mb,1);
 for j=1:length(ss)
   selFea{nn}=ss{j};
   nn=nn+1;
 end


for i=2:length(mb)
     ss=subsetsFixedSize(mb,i);
      for j=1:length(ss)
         ss1=ss{j};
         score=cell(1,M);
         pvalue=zeros(1,M);
         ave_score=0;
         for k=1:M
            for k1=1:length(ss1)
                [score1] = abs(mi_c(data{k}(:,target),data{k}(:,ss1(k1))));
                score{k}=[score{k},score1];
            end
         ave_score=ave_score+mean(score{k});
         end
         ave_score=ave_score/M;
         for k2=1:M
             [h,pvalue(k2)]=ttest(score{k2},ave_score,'alpha',0.05,'tail', 'both');
         end
         if (min(pvalue)>=0.05)
              selFea{nn}=ss1;
              nn=nn+1;
         end
      end   
end
time=toc(start1);


