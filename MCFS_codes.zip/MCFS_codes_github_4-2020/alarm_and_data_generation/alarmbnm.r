 require(graph)

####################################################
#������������alarm����������ֲ���

conp<-vector("list",37)

#names(conp)[]<-rownames(alarmg)

#BOOL =factor(c("TRUE", "FALSE"),levels=c("TRUE", "FALSE"))
 
#LV2 =factor( c("NORMAL", "HIGH"),levels= c("NORMAL", "HIGH"))
#LV3 =factor(c("LOW","NORMAL", "HIGH"),levels=c("LOW","NORMAL", "HIGH"))

#LV4 =factor( c("ZERO", "LOW", "NORMAL", "HIGH"),levels= c("ZERO", "LOW", "NORMAL", "HIGH"))



BOOL =factor(0:1)  
LV2 =factor( 0:1)
LV3 =factor(0:2)  
LV4 =factor(0:3)


#BOOL = c("TRUE", "FALSE")
# LV2 = c("NORMAL", "HIGH")
#LV3 =c("LOW","NORMAL", "HIGH")
# LV4 = c("ZERO", "LOW", "NORMAL", "HIGH")

names(conp)[1]<-"Hypovolemia"

 conp$Hypovolemia<-
 list(
    states = BOOL,
    parents = c(),
    probs =
       # TRUE         False
          c(0.2,         0.8)
)


names(conp)[2]<-"LVFailure"

conp$LVFailure<-list(

    states = BOOL,
    parents = c(),
    probs =
       #  TRUE         False
          c(0.05,        0.95)
       )

names(conp)[3]<-"LVEDVolume"

conp$LVEDVolume<-list(

    states =LV3,
    parents = c("Hypovolemia", "LVFailure"),
    probs =
       # // Low          Normal       High             // Hypovolemia LVFailure
        matrix(c (0.95,        0.04,        0.01,   #         // TRUE        TRUE
          0.98,        0.01,        0.01,   #        // TRUE        False
         0.01,        0.09,        0.9,      #       // False       TRUE
          0.05,        0.9,         0.05),ncol=3,byrow=TRUE)   #       // False       False
          )


names(conp)[4]<-"StrokeVolume"

conp$StrokeVolume<-list(

    states =LV3,
    parents = c("LVFailure", "Hypovolemia"),
    probs =
       # // Low          Normal       High            // LVFailure Hypovolemia
        matrix(c(0.98,        0.01,        0.01,       #   // TRUE      TRUE
          0.5,         0.49,        0.01,     #    // TRUE      False
         0.95,        0.04,        0.01,      #    // False     TRUE
          0.05,        0.9,         0.05),ncol=3,byrow=TRUE)    #   // False     False       ;
  )

names(conp)[5]<-"CVP"

conp$CVP<-list(

    states = LV3,

    parents = "LVEDVolume",
    probs =
      #  // Low          Normal       High              // LVEDVolume
         matrix(c(0.95,        0.04,        0.01,      #     // Low
          0.04,        0.95,        0.01,     #      // Normal
          0.01,        0.29,        0.7),ncol=3,byrow=TRUE)      #      // High
         )


names(conp)[6]<-"PCWP"

conp$PCWP <-list(

    states =LV3,
     parents = c("LVEDVolume"),
    probs =
        #// Low          Normal       High        #   // LVEDVolume
        matrix(c(0.95,        0.04,        0.01,   #      // Low
          0.04,        0.95,        0.01,        # // Normal
          0.01,        0.04,        0.95) ,ncol=3,byrow=TRUE)    #    // High       ;
    )


names(conp)[7]<-"InsuffAnesth"

conp$InsuffAnesth <-list(

    states = BOOL,
    parents = c(),
    probs =
       # // TRUE         False
          c(0.2,         0.8)
    )

names(conp)[8]<-"PulmEmbolus"

conp$PulmEmbolus <-list(
       states =BOOL,
    parents = c(),
    probs =
        #// TRUE         False
          c(0.01,        0.99)
          )


names(conp)[9]<-"Intubation"

conp$Intubation <-list(

    states = LV3,
    parents = c(),
    probs =
       # // Normal       Esophageal   OneSided
          c(0.92,        0.03,        0.05)
          )


names(conp)[10]<-"Shunt"

conp$Shunt <-list(

    states = LV2,
    parents = c("PulmEmbolus", "Intubation"),
    probs =
       # // Normal       High            // PulmEmbolus Intubation
        matrix(c(0.1,         0.9,    #       // TRUE        Normal
          0.1,         0.9,     #      // TRUE        Esophageal
          0.01,        0.99,   #      // TRUE        OneSided
         0.95,        0.05,    #      // False       Normal
          0.95,        0.05,     #     // False       Esophageal
         0.05,        0.95),ncol=2,byrow=TRUE)   #     // False       OneSided   ;
    )




names(conp)[11]<-"KinkedTube"

conp$KinkedTube <-list(

    states = BOOL,
    parents =c(),
    probs =
        #// TRUE         False
          c(0.04,        0.96)
    )


names(conp)[12]<-"MinVolSet"

conp$MinVolSet <-list(

    states = LV3,
    parents = c(),
    probs =
        #// Low          Normal       High
          c(0.01,        0.98,        0.01))


names(conp)[13]<-"VentMach"

conp$VentMach <-list(

    states =LV4,

    parents = c("MinVolSet"),
    probs =
        #// Zero         Low          Normal       High       #    // MinVolSet
       matrix(  c(0.01,        0.97,        0.01,        0.01,      #   // Low
          0.01,        0.01,        0.97,        0.01,       #  // Normal
          0.01,        0.01,        0.01,        0.97),ncol=4,byrow=TRUE)       # // High      ;
  )


names(conp)[14]<-"Disconnect"

conp$Disconnect <-list(

    states =BOOL,
    parents = c(),
    probs =
     #   // TRUE         False
          c(0.05,        0.95)
  )




names(conp)[15]<-"VentTube"

conp$VentTube <-list(

    states = LV4,

    parents = c("VentMach", "Disconnect"),
    probs =
       # // Zero         Low          Normal       High            // VentMach Disconnect
       matrix( c(0.97,        0.01,        0.01,        0.01, #         // Zero     TRUE
        0.97,        0.01,        0.01,        0.01,      #   // Zero     False
        0.97,        0.01,        0.01,        0.01,      #    // Low      TRUE
        0.01,        0.97,        0.01,        0.01,      #   // Low      False
        0.97,        0.01,        0.01,        0.01,      #    // Normal   TRUE
        0.01,        0.01,        0.97,        0.01,      #   // Normal   False
        0.97,        0.01,        0.01,        0.01,      #    // High     TRUE
        0.01,        0.01,        0.01,        0.97),ncol=4,byrow=TRUE)     #   // High     False      ;
    )





names(conp)[16]<-"VentLung"

conp$VentLung <-list(

    states = LV4,

    parents = c("KinkedTube", "VentTube", "Intubation"),
    probs =
       # //  Zero         Low          Normal       High             // KinkedTube VentTube Intubation
      matrix( c(0.97,        0.01,        0.01,        0.01,     #        // TRUE       Zero     Normal
       0.97,        0.01,        0.01,        0.01,     #        // TRUE       Zero     Esophageal
       0.97,        0.01,        0.01,        0.01,     #       // TRUE       Zero     OneSided
       0.95,        0.03,        0.01,        0.01,     #        // TRUE       Low      Normal
       0.97,        0.01,        0.01,        0.01,     #        // TRUE       Low      Esophageal
       0.95,        0.03,        0.01,        0.01,     #       // TRUE       Low      OneSided
       0.4,         0.58,        0.01,        0.01,       #      // TRUE       Normal   Normal
       0.97,        0.01,        0.01,        0.01,       #      // TRUE       Normal   Esophageal
       0.5,         0.48,        0.01,        0.01,       #     // TRUE       Normal   OneSided
       0.3,         0.68,        0.01,        0.01,       #      // TRUE       High     Normal
       0.97,        0.01,        0.01,        0.01,       #      // TRUE       High     Esophageal
       0.3,         0.68,        0.01,        0.01,       #    // TRUE       High     OneSided
       0.97,        0.01,        0.01,        0.01,     #        // False      Zero     Normal
       0.97,        0.01,        0.01,        0.01,     #        // False      Zero     Esophageal
       0.97,        0.01,        0.01,        0.01,     #       // False      Zero     OneSided
       0.01,        0.97,        0.01,        0.01,     #        // False      Low      Normal
       0.97,        0.01,        0.01,        0.01,     #        // False      Low      Esophageal
       0.01,        0.97,        0.01,        0.01,     #       // False      Low      OneSided
       0.01,        0.01,        0.97,        0.01,      #       // False      Normal   Normal
       0.97,        0.01,        0.01,        0.01,      #       // False      Normal   Esophageal
       0.01,        0.01,        0.97,        0.01,      #      // False      Normal   OneSided
       0.01,        0.01,        0.01,        0.97,      #       // False      High     Normal
       0.97,        0.01,        0.01,        0.01,      #       // False      High     Esophageal
       0.01,        0.01,        0.01,        0.97),ncol=4,byrow=TRUE)     #     // False      High     OneSided   ;
    )






names(conp)[17]<-"VentAlv"

conp$VentAlv <-list(

    states =LV4,

    parents = c("Intubation", "VentLung"),
    probs =
       # // Zero         Low          Normal       High            // Intubation VentLung
      matrix( c(0.97,        0.01,        0.01,        0.01,  #           // Normal     Zero
       0.01,        0.97,        0.01,        0.01,    #         // Normal     Low
       0.01,        0.01,        0.97,        0.01,    #         // Normal     Normal
       0.01,        0.01,        0.01,        0.97,    #        // Normal     High
       0.97,        0.01,        0.01,        0.01,    #         // Esophageal Zero
       0.01,        0.97,        0.01,        0.01,      #       // Esophageal Low
       0.01,        0.01,        0.97,        0.01,      #       // Esophageal Normal
       0.01,        0.01,        0.01,        0.97,      #      // Esophageal High
       0.97,        0.01,        0.01,        0.01,      #       // OneSided   Zero
       0.03,        0.95,        0.01,        0.01,      #       // OneSided   Low
       0.01,        0.94,        0.04,        0.01,      #       // OneSided   Normal
       0.01,        0.88,        0.1,         0.01),ncol=4,byrow=TRUE)  #        // OneSided   High     ;
 )





names(conp)[18]<-"FiO2"

conp$FiO2 <-list(
    states = LV2,
    parents = c(),
    probs =
        #// Low          Normal
          c(0.01,        0.99)

)

 names(conp)[19]<-"PVSat"

conp$PVSat <-list(

    states = LV3,

    parents = c("VentAlv", "FiO2"),
    probs =
      #  // Low          Normal       High            // VentAlv FiO2
      matrix( c( 0.98,        0.01,        0.01,     #        // Zero    Low
        0.98,        0.01,        0.01,     #       // Zero    Normal
        0.98,        0.01,        0.01,     #        // Low     Low
        0.98,        0.01,        0.01,     #       // Low     Normal
        0.95,        0.04,        0.01,       #      // Normal  Low
        0.01,        0.95,        0.04,       #     // Normal  Normal
        0.95,        0.04,        0.01,       #      // High    Low
        0.01,        0.01,        0.98),ncol=3,byrow=TRUE)   #     // High    Normal ;
    )








names(conp)[20]<-"SaO2"

conp$SaO2 <-list(

    states =LV3,

    parents = c("Shunt", "PVSat"),
    probs =
      #  // Low          Normal       High            // Shunt  PVSat
         matrix( c(0.98,        0.01,        0.01,     #           // Normal Low
        0.01,        0.98,        0.01,       #         // Normal Normal
        0.01,        0.01,        0.98,       #        // Normal High
        0.98,        0.01,        0.01,         #       // High   Low
        0.98,        0.01,        0.01,         #       // High   Normal
        0.69,        0.3,         0.01),ncol=3,byrow=TRUE)        #      // High   High   ;
    )





names(conp)[21]<-"Anaphylaxis"

conp$Anaphylaxis <-list(
   states = BOOL,
    parents =c(),
    probs =
     #   // TRUE         False
         c (0.01,        0.99)
   )


names(conp)[22]<-"TPR"

conp$TPR <-list(
    states = LV3,

    parents = c("Anaphylaxis"),
    probs =
      #  // Low          Normal       High           #// Anaphylaxis
        matrix (c(0.98,        0.01,        0.01,       #  // TRUE
          0.3,         0.4,         0.3), ncol=3,byrow=TRUE)#       // False       ;
    )

names(conp)[23]<-"ArtCO2"

conp$ArtCO2 <-list(
    states = LV3,
    parents = c("VentAlv"),
    probs =
    #    // Low          Normal       High           // VentAlv
      matrix(c(  0.01,        0.01,        0.98,   #      // Zero
        0.01,        0.01,        0.98,   #      // Low
        0.04,        0.92,        0.04,    #     // Normal
        0.9,         0.09,        0.01), ncol=3,byrow=TRUE)    #    // High    ;
  )






names(conp)[24]<-"Catechol"

conp$Catechol <-list(

    states = LV2,
    parents = c("InsuffAnesth", "SaO2", "TPR", "ArtCO2"),
    probs =
       # //   Normal       High              // InsuffAnesth SaO2   TPR    ArtCO2
       matrix(c( 0.01,        0.99,       #         // TRUE         Low    Low    Low
        0.01,        0.99,       #         // TRUE         Low    Low    Normal
        0.01,        0.99,         #      // TRUE         Low    Low    High
        0.01,        0.99,         #       // TRUE         Low    Normal Low
        0.01,        0.99,       #         // TRUE         Low    Normal Normal
        0.01,        0.99,       #        // TRUE         Low    Normal High
        0.01,        0.99,         #       // TRUE         Low    High   Low
        0.01,        0.99,         #       // TRUE         Low    High   Normal
        0.01,        0.99,     #         // TRUE         Low    High   High
        0.01,        0.99,     #           // TRUE         Normal Low    Low
        0.01,        0.99,       #         // TRUE         Normal Low    Normal
        0.01,        0.99,       #        // TRUE         Normal Low    High
        0.01,        0.99,     #           // TRUE         Normal Normal Low
        0.01,        0.99,     #           // TRUE         Normal Normal Normal
        0.01,        0.99,       #        // TRUE         Normal Normal High
        0.05,        0.95,       #         // TRUE         Normal High   Low
        0.05,        0.95,    #            // TRUE         Normal High   Normal
        0.01,        0.99,    #          // TRUE         Normal High   High
        0.01,        0.99,      #          // TRUE         High   Low    Low
        0.01,        0.99,      #          // TRUE         High   Low    Normal
        0.01,        0.99,     #          // TRUE         High   Low    High
        0.05,        0.95,     #           // TRUE         High   Normal Low
        0.05,        0.95,       #         // TRUE         High   Normal Normal
        0.01,        0.99,       #        // TRUE         High   Normal High
        0.05,        0.95,   #             // TRUE         High   High   Low
        0.05,        0.95,   #             // TRUE         High   High   Normal
        0.01,        0.99,     #        // TRUE         High   High   High
        0.05,        0.95,     #           // False        Low    Low    Low
        0.05,        0.95,    #            // False        Low    Low    Normal
        0.01,        0.99,    #           // False        Low    Low    High
        0.05,        0.95,      #          // False        Low    Normal Low
        0.05,        0.95,      #          // False        Low    Normal Normal
        0.01,        0.99,      #         // False        Low    Normal High
        0.05,        0.95,      #          // False        Low    High   Low
        0.05,        0.95,        #        // False        Low    High   Normal
        0.01,        0.99,        #      // False        Low    High   High
        0.1,         0.9,       #          // False        Normal Low    Low
        0.1,         0.9 ,      #          // False        Normal Low    Normal
        0.1,         0.9,        #        // False        Normal Low    High
        0.95,        0.05,       #         // False        Normal Normal Low
        0.95,        0.05,      #          // False        Normal Normal Normal
        0.3,         0.7,       #         // False        Normal Normal High
        0.95,        0.05,        #        // False        Normal High   Low
        0.95,        0.05,        #        // False        Normal High   Normal
        0.3,         0.7,         #      // False        Normal High   High
        0.95,        0.05,        #        // False        High   Low    Low
        0.95,        0.05,          #      // False        High   Low    Normal
        0.3,         0.7,           #     // False        High   Low    High
        0.99,        0.00999999,    #      // False        High   Normal Low
        0.99,        0.00999999,    #      // False        High   Normal Normal
        0.99,        0.00999999,      #   // False        High   Normal High
        0.95,        0.05,            #    // False        High   High   Low
        0.99,        0.00999999, #     // False        High   High   Normal
        0.3,         0.7),ncol=2,byrow=TRUE)        # // False        High   High   High   ;
  )

names(conp)[25]<-"HR"

conp$HR <-list(
    states = LV3,
    parents = c("Catechol"),
    probs =
       # // Low          Normal       High       #    // Catechol
         matrix(c(0.1,         0.89,        0.01,      #   // Normal
          0.01,        0.09,        0.9),ncol=3,byrow=TRUE)      #   // High     ;
   )

names(conp)[26]<-"CO"

conp$CO <-list(
    states =LV3,
    parents = c("HR", "StrokeVolume"),
    probs =
      #  // Low          Normal       High            // HR     StrokeVolume
    matrix(c(0.98,        0.01,        0.01,        #       // Low    Low
       0.95,        0.04,        0.01,     #          // Low    Normal
       0.3,         0.69,        0.01,     #         // Low    High
       0.95,        0.04,        0.01,       #        // Normal Low
       0.04,        0.95,        0.01,       #        // Normal Normal
       0.01,        0.3,         0.69,      #        // Normal High
       0.8,         0.19,        0.01,      #         // High   Low
       0.01,        0.04,        0.95,        #       // High   Normal
       0.01,        0.01,        0.98),ncol=3,byrow=T)   #     // High   High         ;
   )






names(conp)[27]<-"History"

conp$History <-list(


    states =LV2,

    parents = c("LVFailure"),
    probs =
        #// TRUE         False       #   // LVFailure
         matrix(c(0.9,         0.1,        #  // TRUE
          0.01,        0.99),ncol=2,byrow=TRUE)      #  // False     ;
 )





names(conp)[28]<-"BP"

conp$BP <-list(
    states = LV3,
    parents = c("CO", "TPR"),
    probs =
       # // Low          Normal       High        #     // CO     TPR
       matrix(c(0.98,        0.01,        0.01,      #     // Low    Low
         0.98,        0.01,        0.01,      #     // Low    Normal
         0.3,         0.6,         0.1,      #     // Low    High
         0.98,        0.01,        0.01,       #    // Normal Low
         0.1,         0.85,        0.05,      #     // Normal Normal
         0.05,        0.4,         0.55,     #     // Normal High
         0.9,         0.09,        0.01,     #      // High   Low
         0.05,        0.2,         0.75,     #      // High   Normal
         0.01,        0.09,        0.9),ncol=3,byrow=TRUE)    #      // High   High   ;
   )









names(conp)[29]<-"ErrCauter"

conp$ErrCauter <-list(


    states = BOOL,
    parents = c(),
    probs =
      #  // TRUE         False
          c(0.1,         0.9)
 )






names(conp)[30]<-"HREKG"

conp$HREKG <-list(



    states = LV3,

    parents = c("HR", "ErrCauter"),
    probs =
        #// Low          Normal       High         #    // HR     ErrCauter
       matrix(c( 0.3333333,   0.3333333,   0.3333333,  #    // Low    TRUE
        0.98,        0.01,        0.01,      #    // Low    False
        0.3333333,   0.3333333,   0.3333333,  #    // Normal TRUE
        0.01,        0.98,        0.01,       #   // Normal False
        0.3333333,   0.3333333,   0.3333333,  #    // High   TRUE
        0.01,        0.01,        0.98),ncol=3,byrow=TRUE)     #    // High   False     ;
  )





names(conp)[31]<-"HRSat"

conp$HRSat <-list(



    states =   LV3,

    parents =c ("HR", "ErrCauter"),
    probs =
       # // Low          Normal       High         #    // HR     ErrCauter
       matrix( c(0.3333333,   0.3333333,   0.3333333,  #    // Low    TRUE
        0.98,        0.01,        0.01,      #    // Low    False
        0.3333333,   0.3333333,   0.3333333,  #    // Normal TRUE
        0.01,        0.98,        0.01,       #   // Normal False
        0.3333333,   0.3333333,   0.3333333,  #    // High   TRUE
        0.01,        0.01,        0.98),ncol=3,byrow=TRUE)     #    // High   False     ;
   )








names(conp)[32]<-"ErrLowOutput"

conp$ErrLowOutput <-list(



    states = BOOL,
    parents = c(),
    probs =
       # // TRUE         False
          c(0.05,        0.95)
   )






names(conp)[33]<-"HRBP"

conp$HRBP <-list(



    states = LV3,

    parents = c("ErrLowOutput", "HR"),
    probs =
        #// Low          Normal       High     #        // ErrLowOutput HR
        matrix(c(0.98,        0.01,        0.01,   #        // TRUE         Low
         0.4,         0.59,        0.01,   #        // TRUE         Normal
         0.3,         0.4,         0.3,   #        // TRUE         High
         0.98,        0.01,        0.01,    #       // False        Low
         0.01,        0.98,        0.01,   #        // False        Normal
         0.01,        0.01,        0.98),ncol=3,byrow=TRUE) #        // False        High   ;
  )








names(conp)[34]<-"ExpCO2"

conp$ExpCO2 <-list(



    states =LV4,

    parents = c("ArtCO2", "VentLung"),
    probs =
       # // Zero         Low          Normal       High      #       // ArtCO2 VentLung
        matrix(c(0.97,        0.01,        0.01,        0.01,    #       // Low    Zero
         0.01,        0.97,        0.01,        0.01,    #       // Low    Low
         0.01,        0.97,        0.01,        0.01,    #       // Low    Normal
         0.01,        0.97,        0.01,        0.01,    #      // Low    High
         0.97,        0.01,        0.01,        0.01,    #       // Normal Zero
         0.01,        0.01,        0.97,        0.01,    #       // Normal Low
         0.01,        0.01,        0.97,        0.01,     #      // Normal Normal
         0.01,        0.01,        0.97,        0.01,    #      // Normal High
         0.97,        0.01,        0.01,        0.01,     #      // High   Zero
         0.01,        0.01,        0.01,        0.97,     #      // High   Low
         0.01,        0.01,        0.01,        0.97,      #     // High   Normal
         0.01,        0.01,        0.01,        0.97),ncol=4,byrow=TRUE)   #      // High   High     ;
  )





names(conp)[35]<-"PAP"

conp$PAP <-list(



    states =  LV3,

    parents =c ("PulmEmbolus"),
    probs =
       # // Low          Normal       High     #      // PulmEmbolus
        matrix (c(0.01,        0.19,        0.8,     #     // TRUE
          0.05,        0.9,         0.05),ncol=3,byrow=TRUE)   #     // False       ;
 )






names(conp)[36]<-"Press"

conp$Press <-list(

    states = LV4,

    parents = c("KinkedTube", "Intubation", "VentTube"),
    probs =
       # //  Zero         Low          Normal       High        #      // KinkedTube Intubation VentTube
        matrix(c(0.97,        0.01,        0.01,        0.01,      #      // TRUE       Normal     Zero
         0.01,        0.49,        0.3,         0.2,       #      // TRUE       Normal     Low
         0.01,        0.01,        0.08,        0.9,       #      // TRUE       Normal     Normal
         0.01,        0.01,        0.01,        0.97,      #     // TRUE       Normal     High
         0.97,        0.01,        0.01,        0.01,      #      // TRUE       Esophageal Zero
         0.1,         0.84,        0.05,        0.01,      #      // TRUE       Esophageal Low
         0.05,        0.25,        0.25,        0.45,      #      // TRUE       Esophageal Normal
         0.01,        0.15,        0.25,        0.59,     #      // TRUE       Esophageal High
         0.97,        0.01,        0.01,        0.01,      #      // TRUE       OneSided   Zero
         0.01,        0.29,        0.3,         0.4,       #      // TRUE       OneSided   Low
         0.01,        0.01,        0.08,        0.9,        #     // TRUE       OneSided   Normal
         0.01,        0.01,        0.01,        0.97,    #        // TRUE       OneSided   High
         0.97,        0.01,        0.01,        0.01,      #      // False      Normal     Zero
         0.01,        0.97,        0.01,        0.01,       #     // False      Normal     Low
         0.01,        0.01,        0.97,        0.01,       #     // False      Normal     Normal
         0.01,        0.01,        0.01,        0.97,      #     // False      Normal     High
         0.97,        0.01,        0.01,        0.01,       #     // False      Esophageal Zero
         0.4,         0.58,        0.01,        0.01,        #    // False      Esophageal Low
         0.2,         0.75,        0.04,        0.01,       #     // False      Esophageal Normal
         0.2,         0.7,         0.09,        0.01,      #     // False      Esophageal High
         0.97,        0.01,        0.01,        0.01,       #     // False      OneSided   Zero
         0.01,        0.9,         0.08,        0.01,       #     // False      OneSided   Low
         0.01,        0.01,        0.38,        0.6,        #     // False      OneSided   Normal
         0.01,        0.01,        0.01,        0.97),ncol=4,byrow=TRUE)    #     // False      OneSided   High     ;

)

names(conp)[37]<-"MinVol"

conp$MinVol <-list(

    states = LV4,

    parents =c("VentLung", "Intubation"),
    probs =
       # // Zero         Low          Normal       High            // VentLung Intubation
       matrix(c( 0.97,        0.01,        0.01,        0.01,  #       // Zero     Normal
        0.97,        0.01,        0.01,        0.01,  #        // Zero     Esophageal
        0.97,        0.01,        0.01,        0.01,  #       // Zero     OneSided
        0.01,        0.97,        0.01,        0.01,  #        // Low      Normal
        0.6,         0.38,        0.01,        0.01,   #       // Low      Esophageal
        0.01,        0.97,        0.01,        0.01,  #       // Low      OneSided
        0.01,        0.01,        0.97,        0.01,  #        // Normal   Normal
        0.5,         0.48,        0.01,        0.01,  #        // Normal   Esophageal
        0.01,        0.01,        0.97,        0.01,  #       // Normal   OneSided
        0.01,        0.01,        0.01,        0.97,  #        // High     Normal
        0.5,         0.48,        0.01,        0.01,  #        // High     Esophageal
        0.01,        0.01,        0.01,        0.97),ncol=4,byrow=TRUE)#        // High     OneSided   ;
)


############################################################
############################################################

#�����µ���

setClass("bnm", representation =
	 list(graph = "graph",
	      conp="list"	         
              ))

p<-length(conp)
G=matrix(0,ncol=p,nrow=p)
rownames(G)<-colnames(G)<-names(conp)

#����һ���������ʵ���������
#$conp$nodename$probs[,index[]]

for (i in 1:p)
  { 
    pa<-conp[[i]]$parents
    
    if (!is.null(pa))
       { G[pa,i]<-1
         np<-length(pa)
         dimp<-rep(1,np+1)
         nps<-1
         for (j in np:1) dimp[j]<-dimp[j+1]*length(conp[[pa[j]]]$states)
         dimp<-dimp[-1]
         conp[[i]]$dimp<-dimp

         #intg<-as.integer(parents)-1
         # index<-intg%*%dimp+1
         #conp(|pa)<-probs[,index]
        } else   conp[[i]]$dimp<-1
   }
Gm<-as(G,"graphNEL")

alarmbnm<-new("bnm",
         graph=Gm,
         conp=conp )


