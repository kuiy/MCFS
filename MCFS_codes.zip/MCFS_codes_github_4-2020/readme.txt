
The codes the MCFS algorithm of the paper titled with "Multi-Source Causal Feature selection"
and are implemented in MATLAB

Yu, Kui, et al. "Multi-Source Causal Feature Selection." IEEE Transactions on Pattern Analysis and Machine Intelligence (2019).



1. Main functions:

mcfs_d.m: MSCF for discrete data

mcfs_z.m: MCFS for continuous data


2. The packages MCSF used are listed as follows.

(a) MIToolbox: Mutual Information functions for C and MATLAB
(an excellent MATLAB feature selection toolbox)

https://github.com/Craigacp/MIToolbox

(b) Causal Explorer: (A well-known causal strucuture learning and causal feature selection package)

HITON-MB was implemented in the Causal Explorer package

Aliferis, Constantin F., Ioannis Tsamardinos, Alexander R. Statnikov, and Laura E. Brown.
 "Causal Explorer: A Causal Probabilistic Network Learning Toolkit for Biomedical Discovery.
" In METMBS, vol. 3, pp. 371-376. 2003.

If the Causal Explorer package is not able to run in the advanced version of MATLAB, 
(1) you can try implment it in MATLAB R2014a，or
(2) use the HITON-MB codes implemented by the authors of the paper in the MCFS-Alg folder.



3. Implementing example:

[selFea,time] = mcfs_c(d,15,0.01)

[acc]=nb_mcfs(d,test,15,selFea)
[a,b]=max(acc)

[acc]=knn_mcfs(d,test,15,selFea,3)
[a,b]=max(acc)


4. The folder of "alarm_and_data_generation"

The R codes for generating interventional data using the ALARM network



















