function [acc]=knn_vote_mcfs(train_data,test_data,class_attribute,selFea,kk)


acc=zeros(1,length(selFea));
acc1=zeros(1,length(selFea));
auc=0;
test_class=cell(1,length(train_data));
[n,p]=size(test_data(:,class_attribute));
class_size=length(unique(test_data(:,class_attribute)));

for zz=1:length(selFea)
    
     vote_lable=zeros(1,length(test_data(:,class_attribute)));
     aa=[];
     for i=1:length(train_data)
        test_class{i} = knnclassify(test_data(:,selFea{zz}),train_data{i}(:,selFea{zz}), train_data{i}(:,class_attribute),kk);
        aa=[aa test_class{i}];
     end
     
    
  for i=1:n
         
 %for multiple classes       
%           a=zeros(1,class_size);
%           bb=-1;
%           bbb=1;
%           for j=1:class_size
%              a(j)=length(find(aa(i,:)==j));
%              if a(j)>bb
%                  bb=a(j);
%                  bbb=j;
%              end
%           end
%              
%      vote_lable(i)=bbb;

%for two-classes:

         ww1=length(find(aa(i,:)==0));
         ww2=length(find(aa(i,:)==1));
         
         if ww1==2
             vote_lable(i)=0;
         end
         
         if ww2==2
             vote_lable(i)=1;
         end
         if ww1==ww2
            %a=randperm(2);  
           %vote_lable(i)=a(1)-1;
           vote_lable(i)=aa(i,1);
         end
                 
  end  
       %acc1(zz)=sum(test_data(:,class_attribute)==vote_lable')/length(vote_lable)*100;
       acc(zz)=length(find(test_data(:,class_attribute)== vote_lable'))/length(vote_lable)*100;
            
                    
end



