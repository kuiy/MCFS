
[acc]=nb_vote_mcfs(d,test,1,selFea)



